package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import java.util.SequencedMap;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;

@Mixin(MultiBufferSource.BufferSource.class)
public interface AccessorMultiBufferSource {
	@Accessor("sharedBuffer")
	ByteBufferBuilder getFallbackBuffer();

	@Accessor("fixedBuffers")
	SequencedMap<RenderType, ByteBufferBuilder> getFixedBuffers();
}
